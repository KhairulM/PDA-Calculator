/*****CARA MENJALANKAN PROGRAM*****/
/***DENGAN DI-COMPILE DULU***/
1. Buka Terminal atau CMD pada ..\src
2. Ketik "gcc -o MAIN tbfoTubes2.c" tanpa tanda kutip
3. Jika memakai OS Windows ketik "MAIN" tanpa tanda kutip
4. Jika memakai OS Linux ketik "./MAIN" tanda tanda kutip

/***DENGAN LANGSUNG MENJALANKAN file MAIN.EXE***/
/HANYA BERLAKU UNTUK WINDOWS/
1. Buka Terminal atau CMD pada ..\bin
2. Klik 2 kali pada file "MAIN.exe"