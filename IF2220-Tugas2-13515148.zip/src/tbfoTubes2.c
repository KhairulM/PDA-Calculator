#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "boolean.h"

/*************************************************/
// E -> E+T | E-T | T
// T -> T*P | T/P | P
// P -> P^F | P^P | F
// F -> (E) | N | -N 
// N -> 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | .

/*************************************************/

//DEFINISI FUNGSI
float evalExpression(); // penjumlahan dan pengurangan
float evalTerm();		// perkalian dan pembagian
float evalPower();		// perpangkatan
float evalFactor();		// operasi bilangan tunggal, tanda '.', tanda kurung
boolean isSymbol();
boolean isNumber();

//KAMUS GLOBAL
char *s;
int panjangToken;
boolean valid; // jika syntax error, valid = false.
boolean error; // Jika hasil bagi tidak terdefinisi, error = true.


//REALISASI FUNGSI
boolean isSymbol() {  
    return (*s == '.') || (*s == '+') ||(*s == '*') || (*s == '/') || (*s == '^');
}

boolean isNumber() {
	return (*s >= ('0'-'0')) && (*s <= ('9'-'0'));
}

float evalExpression() {
	float term_value = evalTerm();
	while (*s == '+' || *s == '-'){
		if (*s == '+') {
			s++;
			if (isSymbol() || *s == '-')
				valid = false;
			else {	
				float value = evalTerm();
				term_value = term_value + value;
			}
		}
		else if (*s == '-'){
			s++;
			if (isSymbol() || *s == '-')
				valid = false;
			else {
				float value = evalTerm();
				term_value = term_value - value;
			}
		}
	}

	return term_value;
}


float evalTerm() {
	float power_value = evalPower();
	while (*s == '*' || *s == '/') {
		if (*s == '*'){
			s++;
			if (isSymbol() || *s == '-')
				valid = false;
			else {
				float value = evalPower();
				power_value = power_value * value;
			}
		}
		else if (*s == '/') {
			s++;
			if (isSymbol() || *s == '-')
				valid = false;
			else {
				float value = evalPower();
				if (value == 0)
					error = true;
				else
					power_value = power_value / value;
			}
		}
	}
	
	return power_value;
}

float evalPower(){
	float base = evalFactor();
	while (*s == '^') {
		s++;
		if (isSymbol() || *s == '-')
			valid = false;
		else {	
			float power = evalPower();
			if (base <0 && power > 0 && power <1)
				error = true;
			base = pow((double)base,(double)power);
		}
	}
	
	return base;
}

float evalFactor() {
	float factor_value = 0;
	while (*s >='0' && *s <='9'){
		factor_value = factor_value*10;
		factor_value = factor_value + *s - '0';
		s++;
	}
	
	if (panjangToken == 1 && (!isNumber() || isSymbol() || *s==')' || *s=='(' || *s=='-'))
		valid = false;
	else {
		int koma = 0;
		while (*s == '.'){
			s++;
			koma++;
			if (isSymbol() || *s == '-' || *s == ')' || *s== '(' || koma >1)
				valid = false;
			else {
				float dec = 1;
				while (*s >='0' && *s <='9') {
					dec = dec/10;
					float num = (*s - '0')*dec;
					factor_value = factor_value + num;
					s++;
				}
			}
		}
		if (*s == '(') {
			s++;
			if (isSymbol() || *s == ')')
				valid = false;
			else {
				float value = evalExpression();
				s++;
				return value;
			}
		}
	}
	
	return factor_value;
}


//PROGRAM UTAMA DAN IMPLEMENTASI FUNGSI
int main () {
	valid = true;
	error = false;
		
	printf("==========Selamat datang di Kalkulator==========\n");
	printf("Silakan masukkan operasi matematika yang diinginkan.\n");
	printf("Masukkan 'e' untuk keluar dari program.");
	printf("\n");
	printf("Masukkan token:\n");
	printf("\n");

	s = malloc(sizeof(char)*1000);
	
	scanf("%s", s);
	
	while (*s != 'e') {
		panjangToken = strlen(s);
		float hasil = evalExpression();
		if (valid && !error)
			printf("%.2f\n", hasil);
		else if (!valid && !error)
			printf("Syntax ERROR\n");
		else if (error)
			printf("Math ERROR\n");
		
		valid = true;
		error = false;
		scanf("%s", s);
	}
	
	printf("Terima kasih sudah pakai kalkulatornya\n");	
	return 0;
}
